---
name: OpenAPI numeric compatibility
description: The workspace's generated Zod validator currently cannot compile zod.int() output.
---

Use numeric OpenAPI schemas without the integer format when adding API contracts in this workspace; validate integer semantics at the route or database boundary instead.

**Why:** The installed Zod version exposes number validation but not the generated `int()` helper, so integer-formatted schemas make library typechecking fail after codegen.

**How to apply:** Prefer `type: number` with min/max constraints in `lib/api-spec/openapi.yaml`, then round or validate values in server handlers and store them in integer database columns.