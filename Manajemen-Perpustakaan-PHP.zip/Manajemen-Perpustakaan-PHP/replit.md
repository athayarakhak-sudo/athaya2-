# Manajemen Perpustakaan

Aplikasi katalog perpustakaan full-stack untuk mengelola koleksi buku, pencarian, kategori, dan cover.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — menjalankan API server
- `pnpm --filter @workspace/perpustakaan run dev` — menjalankan aplikasi web
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — koneksi PostgreSQL terkelola Replit

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/perpustakaan/src/` — aplikasi web katalog
- `artifacts/api-server/src/routes/books.ts` — CRUD buku
- `artifacts/api-server/src/routes/catalog.ts` — kategori dan ringkasan katalog
- `lib/db/src/schema/books.ts` — sumber schema database
- `lib/api-spec/openapi.yaml` — kontrak API dan sumber codegen
- `artifacts/perpustakaan/database.sql` — referensi schema MariaDB sesuai spesifikasi awal

## Architecture decisions

- Frontend React + Vite dan API Express dipakai agar aplikasi dapat dijalankan langsung oleh workflow Replit.
- Database development memakai PostgreSQL terkelola Replit; `database.sql` disertakan sebagai referensi MariaDB dari spesifikasi awal.
- Cover buku dikirim sebagai data URL dari form untuk menjaga alur upload tetap sederhana di preview tanpa dependensi storage eksternal.

## Product

Pengguna dapat melihat, mencari, memfilter, menambah, mengedit, dan menghapus buku. Ringkasan koleksi dan distribusi kategori ditampilkan di halaman utama.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
