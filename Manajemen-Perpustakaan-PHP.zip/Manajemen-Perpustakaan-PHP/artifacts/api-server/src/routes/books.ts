import { Router, type IRouter } from "express";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { db, booksTable } from "@workspace/db";
import {
  CreateBookBody,
  CreateBookResponse,
  DeleteBookParams,
  GetBookParams,
  GetBookResponse,
  ListBooksQueryParams,
  ListBooksResponse,
  UpdateBookBody,
  UpdateBookParams,
  UpdateBookResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const MAX_COVER_DATA_URL_LENGTH = 2_800_000;

function hasValidCover(cover: string | null | undefined): boolean {
  if (cover == null || cover === "") return true;
  return (
    cover.length <= MAX_COVER_DATA_URL_LENGTH &&
    /^data:image\/(jpeg|png);base64,[a-z0-9+/]+=*$/i.test(cover)
  );
}

router.get("/books", async (req, res): Promise<void> => {
  const parsed = ListBooksQueryParams.safeParse(req.query);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid book list query");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const { search, category } = parsed.data;
  const conditions = [];
  if (search) {
    conditions.push(
      or(ilike(booksTable.title, `%${search}%`), ilike(booksTable.author, `%${search}%`)),
    );
  }
  if (category && category !== "all") {
    conditions.push(eq(booksTable.category, category));
  }

  const books = await db
    .select()
    .from(booksTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(booksTable.createdAt));

  res.json(ListBooksResponse.parse(books));
});

router.post("/books", async (req, res): Promise<void> => {
  const parsed = CreateBookBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid book body");
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!hasValidCover(parsed.data.cover)) {
    res.status(400).json({ error: "Cover harus berupa JPG/PNG dan berukuran maksimal 2 MB" });
    return;
  }

  const [book] = await db.insert(booksTable).values({
    ...parsed.data,
    publicationYear: Math.round(parsed.data.publicationYear),
  }).returning();

  res.status(201).json(CreateBookResponse.parse(book));
});

router.get("/books/:id", async (req, res): Promise<void> => {
  const parsed = GetBookParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [book] = await db
    .select()
    .from(booksTable)
    .where(eq(booksTable.id, parsed.data.id));

  if (!book) {
    res.status(404).json({ error: "Buku tidak ditemukan" });
    return;
  }

  res.json(GetBookResponse.parse(book));
});

router.patch("/books/:id", async (req, res): Promise<void> => {
  const params = UpdateBookParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateBookBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  if (!hasValidCover(parsed.data.cover)) {
    res.status(400).json({ error: "Cover harus berupa JPG/PNG dan berukuran maksimal 2 MB" });
    return;
  }

  const [book] = await db
    .update(booksTable)
    .set({
      ...parsed.data,
      publicationYear: Math.round(parsed.data.publicationYear),
    })
    .where(eq(booksTable.id, params.data.id))
    .returning();

  if (!book) {
    res.status(404).json({ error: "Buku tidak ditemukan" });
    return;
  }

  res.json(UpdateBookResponse.parse(book));
});

router.delete("/books/:id", async (req, res): Promise<void> => {
  const parsed = DeleteBookParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [book] = await db
    .delete(booksTable)
    .where(eq(booksTable.id, parsed.data.id))
    .returning({ id: booksTable.id });

  if (!book) {
    res.status(404).json({ error: "Buku tidak ditemukan" });
    return;
  }

  res.sendStatus(204);
});

export default router;