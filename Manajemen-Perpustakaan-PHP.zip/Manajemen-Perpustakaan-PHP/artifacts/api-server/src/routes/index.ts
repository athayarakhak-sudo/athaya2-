import { Router, type IRouter } from "express";
import healthRouter from "./health";
import booksRouter from "./books";
import catalogRouter from "./catalog";

const router: IRouter = Router();

router.use(healthRouter);
router.use(booksRouter);
router.use(catalogRouter);

export default router;
