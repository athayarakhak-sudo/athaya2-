import { Router, type IRouter } from "express";
import { count, desc, eq } from "drizzle-orm";
import { db, booksTable } from "@workspace/db";
import {
  GetCatalogSummaryResponse,
  ListCategoriesResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/categories", async (_req, res): Promise<void> => {
  const rows = await db
    .selectDistinct({ category: booksTable.category })
    .from(booksTable)
    .orderBy(booksTable.category);
  res.json(ListCategoriesResponse.parse(rows.map((row) => row.category)));
});

router.get("/summary", async (_req, res): Promise<void> => {
  const [total] = await db.select({ count: count() }).from(booksTable);
  const categoryRows = await db
    .select({ name: booksTable.category, count: count() })
    .from(booksTable)
    .groupBy(booksTable.category)
    .orderBy(desc(count()));
  const [newest] = await db
    .select({ title: booksTable.title })
    .from(booksTable)
    .orderBy(desc(booksTable.createdAt))
    .limit(1);

  res.json(GetCatalogSummaryResponse.parse({
    totalBooks: Number(total?.count ?? 0),
    totalCategories: categoryRows.length,
    newestBook: newest?.title ?? null,
    categories: categoryRows.map((row) => ({
      name: row.name,
      count: Number(row.count),
    })),
  }));
});

export default router;