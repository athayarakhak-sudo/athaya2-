import { useState, type ReactNode } from "react";
import { BookOpen, ChevronDown, LibraryBig, Plus, Search, Sparkles } from "lucide-react";
import { Link, useLocation } from "wouter";
import { getHealthCheckQueryKey, useHealthCheck } from "@workspace/api-client-react";

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), retry: 1 } });

  return (
    <div className="min-h-[100dvh] bg-background text-foreground">
      <aside className={`fixed inset-y-0 left-0 z-40 w-[252px] -translate-x-full bg-sidebar text-sidebar-foreground transition-transform duration-300 md:translate-x-0 ${mobileOpen ? "translate-x-0" : ""}`}>
        <div className="flex h-full flex-col px-5 py-6">
          <Link href="/" className="mb-12 flex items-center gap-3" data-testid="link-brand">
            <span className="grid h-10 w-10 place-items-center rounded-[13px] bg-sidebar-primary text-sidebar-primary-foreground shadow-sm">
              <LibraryBig size={21} strokeWidth={1.8} />
            </span>
            <span>
              <span className="block font-display text-[21px] leading-none tracking-[-0.03em]">Pustaka Raya</span>
              <span className="mt-1 block font-mono-ui text-[9px] uppercase tracking-[0.18em] text-sidebar-foreground/55">Collection desk</span>
            </span>
          </Link>

          <div className="mb-3 px-3 font-mono-ui text-[9px] uppercase tracking-[0.22em] text-sidebar-foreground/42">Workspace</div>
          <nav className="space-y-1" aria-label="Main navigation">
            <Link
              href="/"
              onClick={() => setMobileOpen(false)}
              data-testid="link-catalog"
              className={`flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition-colors ${location === "/" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground"}`}
            >
              <BookOpen size={17} strokeWidth={1.8} />
              <span>Catalog</span>
              <span className="ml-auto font-mono-ui text-[10px] text-sidebar-foreground/35">01</span>
            </Link>
            <Link
              href="/books/new"
              onClick={() => setMobileOpen(false)}
              data-testid="link-add-book"
              className={`flex items-center gap-3 rounded-xl px-3 py-3 text-[13px] font-semibold transition-colors ${location === "/books/new" ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-sidebar-foreground/65 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground"}`}
            >
              <Plus size={17} strokeWidth={1.8} />
              <span>Add a book</span>
              <span className="ml-auto font-mono-ui text-[10px] text-sidebar-foreground/35">02</span>
            </Link>
          </nav>

          <div className="mt-auto rounded-2xl border border-sidebar-border bg-sidebar-accent/40 p-4">
            <div className="mb-5 flex items-center justify-between">
              <span className="font-mono-ui text-[9px] uppercase tracking-[0.18em] text-sidebar-foreground/48">System pulse</span>
              <span className={`h-2 w-2 rounded-full ${health.isError ? "bg-destructive" : "bg-sidebar-primary"}`} />
            </div>
            <p className="font-display text-[19px] leading-[1.15] text-sidebar-foreground/90">
              {health.isLoading ? "Checking the desk…" : health.isError ? "Desk needs attention." : "The reading room is open."}
            </p>
            <p className="mt-2 text-[11px] leading-relaxed text-sidebar-foreground/48">
              {health.isError ? "The catalog service is not answering right now." : "Catalog changes are saved to the collection as you make them."}
            </p>
          </div>
          <div className="mt-5 flex items-center justify-between px-1 text-[10px] text-sidebar-foreground/35">
            <span>PR / 2024</span>
            <Sparkles size={13} />
          </div>
        </div>
      </aside>

      {mobileOpen && <button className="fixed inset-0 z-30 bg-sidebar/35 md:hidden" onClick={() => setMobileOpen(false)} aria-label="Close navigation" data-testid="button-close-navigation" />}
      <main className="min-h-[100dvh] md:pl-[252px]">
        <header className="sticky top-0 z-20 flex h-[72px] items-center justify-between border-b border-border/70 bg-background/90 px-5 backdrop-blur-md md:px-10">
          <div className="flex items-center gap-3">
            <button className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-card md:hidden" onClick={() => setMobileOpen(true)} aria-label="Open navigation" data-testid="button-open-navigation">
              <ChevronDown size={17} className="-rotate-90" />
            </button>
            <div className="hidden items-center gap-2 text-[11px] text-muted-foreground sm:flex">
              <Search size={14} />
              <span>Collection desk</span>
              <span className="text-border">/</span>
              <span className="font-semibold text-foreground">{location === "/" ? "Catalog" : location === "/books/new" ? "New record" : "Edit record"}</span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden font-mono-ui text-[9px] uppercase tracking-[0.15em] text-muted-foreground sm:inline">Bandung · West Java</span>
            <div className="grid h-8 w-8 place-items-center rounded-full bg-accent font-display text-sm text-accent-foreground" title="Collection librarian">R</div>
          </div>
        </header>
        <div className="page-enter">{children}</div>
      </main>
    </div>
  );
}