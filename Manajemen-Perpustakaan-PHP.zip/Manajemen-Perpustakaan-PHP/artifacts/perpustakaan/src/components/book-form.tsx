import { ChangeEvent, FormEvent, useEffect, useState } from "react";
import { ImagePlus, LoaderCircle, Save, Upload, X } from "lucide-react";
import type { Book, BookInput } from "@workspace/api-client-react";
import { BookCover } from "@/components/book-cover";

export type BookFormValues = BookInput;

type BookFormProps = {
  initialBook?: Book;
  categories: string[];
  onSubmit: (values: BookInput) => void;
  isPending: boolean;
  error?: boolean;
};

const blank: BookInput = { title: "", author: "", publisher: "", publicationYear: new Date().getFullYear(), category: "", description: "", cover: null };

export function BookForm({ initialBook, categories, onSubmit, isPending, error }: BookFormProps) {
  const [values, setValues] = useState<BookInput>(initialBook ? {
    title: initialBook.title,
    author: initialBook.author,
    publisher: initialBook.publisher,
    publicationYear: initialBook.publicationYear,
    category: initialBook.category,
    description: initialBook.description ?? "",
    cover: initialBook.cover,
  } : blank);
  const [validation, setValidation] = useState("");

  useEffect(() => {
    if (!initialBook) return;
    setValues({
      title: initialBook.title,
      author: initialBook.author,
      publisher: initialBook.publisher,
      publicationYear: initialBook.publicationYear,
      category: initialBook.category,
      description: initialBook.description ?? "",
      cover: initialBook.cover,
    });
  }, [initialBook]);

  const change = (field: keyof BookInput, value: string | number | null) => setValues((current) => ({ ...current, [field]: value }));

  const handleUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const allowedTypes = ["image/jpeg", "image/png"];
    if (!allowedTypes.includes(file.type)) {
      setValidation("Please choose a JPG, JPEG, or PNG image for the cover.");
      event.target.value = "";
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setValidation("Cover files must be 2 MB or smaller.");
      event.target.value = "";
      return;
    }
    const reader = new FileReader();
    reader.onload = () => change("cover", typeof reader.result === "string" ? reader.result : null);
    reader.readAsDataURL(file);
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (!values.title.trim() || !values.author.trim() || !values.publisher.trim() || !values.category.trim()) {
      setValidation("Title, author, publisher, and category are required.");
      return;
    }
    if (values.publicationYear < 1000 || values.publicationYear > 2100) {
      setValidation("Publication year must sit between 1000 and 2100.");
      return;
    }
    setValidation("");
    onSubmit({ ...values, title: values.title.trim(), author: values.author.trim(), publisher: values.publisher.trim(), category: values.category.trim(), description: values.description?.trim() || null });
  };

  return (
    <form onSubmit={submit} className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_290px]" data-testid="form-book">
      <section className="rounded-2xl border border-border/80 bg-card p-5 shadow-[0_2px_0_hsl(185_30%_19%_/_0.02)] sm:p-7">
        <div className="mb-7 flex items-end justify-between border-b border-border/70 pb-5">
          <div>
            <p className="font-mono-ui text-[9px] uppercase tracking-[0.2em] text-accent-foreground/70">Record details</p>
            <h2 className="mt-2 font-display text-[27px] tracking-[-0.035em]">Tell us about this book</h2>
          </div>
          <span className="font-mono-ui text-[10px] text-muted-foreground">01 / 02</span>
        </div>
        <div className="grid gap-x-5 gap-y-5 sm:grid-cols-2">
          <Field label="Book title" required value={values.title} onChange={(event) => change("title", event.target.value)} placeholder="e.g. The Door in the Wall" testId="input-book-title" />
          <Field label="Author" required value={values.author} onChange={(event) => change("author", event.target.value)} placeholder="e.g. Marguerite de Angeli" testId="input-book-author" />
          <Field label="Publisher" required value={values.publisher} onChange={(event) => change("publisher", event.target.value)} placeholder="e.g. Doubleday" testId="input-book-publisher" />
          <Field label="Publication year" required type="number" value={values.publicationYear} onChange={(event) => change("publicationYear", Number(event.target.value))} min={1000} max={2100} testId="input-book-year" />
          <label className="space-y-2 sm:col-span-2">
            <span className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Category <span className="text-accent-foreground">*</span></span>
            <input list="category-options" value={values.category} onChange={(event) => change("category", event.target.value)} placeholder="Select or type a category" className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20" data-testid="input-book-category" />
            <datalist id="category-options">{categories.map((category) => <option value={category} key={category} />)}</datalist>
          </label>
          <label className="space-y-2 sm:col-span-2">
            <span className="text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">Description <span className="font-normal normal-case tracking-normal text-muted-foreground/70">(optional)</span></span>
            <textarea value={values.description ?? ""} onChange={(event) => change("description", event.target.value)} placeholder="A short note for the next librarian or curious reader…" rows={5} className="w-full resize-y rounded-xl border border-input bg-background px-3 py-3 text-sm leading-relaxed outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20" data-testid="input-book-description" />
          </label>
        </div>
        {(validation || error) && <div className="mt-6 rounded-xl border border-destructive/25 bg-destructive/8 px-4 py-3 text-sm text-destructive" role="alert" data-testid="status-form-error">{validation || "This record could not be saved. Please try again."}</div>}
        <div className="mt-8 flex flex-wrap items-center justify-between gap-4 border-t border-border/70 pt-6">
          <p className="text-[11px] text-muted-foreground"><span className="text-accent-foreground">*</span> Required fields</p>
          <button type="submit" disabled={isPending} className="inline-flex h-11 items-center gap-2 rounded-xl bg-primary px-5 text-sm font-bold text-primary-foreground transition hover:bg-primary/90 disabled:cursor-wait disabled:opacity-60" data-testid="button-save-book">
            {isPending ? <LoaderCircle size={16} className="animate-spin" /> : <Save size={16} />}
            {isPending ? "Saving record…" : initialBook ? "Save changes" : "Add to collection"}
          </button>
        </div>
      </section>

      <aside className="space-y-5">
        <section className="rounded-2xl border border-border/80 bg-card p-5">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <p className="font-mono-ui text-[9px] uppercase tracking-[0.2em] text-muted-foreground">02 / 02</p>
              <h2 className="mt-1 font-display text-[22px] tracking-[-0.03em]">Cover art</h2>
            </div>
            <ImagePlus size={19} className="text-accent-foreground" />
          </div>
          <div className="flex justify-center rounded-xl bg-secondary/50 py-6">
            <BookCover title={values.title || "Untitled record"} author={values.author} cover={values.cover} size="medium" />
          </div>
          <div className="mt-5">
            <label className="flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed border-input bg-background text-xs font-bold transition hover:border-accent hover:bg-accent/10" data-testid="label-upload-cover">
              <Upload size={15} />
              {values.cover ? "Replace cover" : "Upload cover"}
              <input type="file" accept="image/*" className="sr-only" onChange={handleUpload} data-testid="input-cover-upload" />
            </label>
            {values.cover && <button type="button" onClick={() => change("cover", null)} className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground hover:text-destructive" data-testid="button-remove-cover"><X size={13} /> Remove cover</button>}
          </div>
          <p className="mt-4 text-[11px] leading-relaxed text-muted-foreground">JPG or PNG, preferably a portrait image. The cover is stored with the record.</p>
        </section>
        <div className="rounded-2xl border border-accent/30 bg-accent/12 p-5">
          <p className="font-display text-[19px] leading-tight">A good shelf starts with good notes.</p>
          <p className="mt-2 text-[11px] leading-relaxed text-foreground/60">Add one useful detail in the description — it will help a neighbor find the right next book.</p>
        </div>
      </aside>
    </form>
  );
}

function Field({ label, required, testId, ...props }: { label: string; required?: boolean; testId: string; type?: string; value: string | number; onChange: (event: ChangeEvent<HTMLInputElement>) => void; placeholder?: string; min?: number; max?: number }) {
  return (
    <label className="space-y-2">
      <span className="flex items-center gap-1 text-[11px] font-bold uppercase tracking-[0.12em] text-muted-foreground">{label} {required && <span className="text-accent-foreground">*</span>}</span>
      <input {...props} className="h-11 w-full rounded-xl border border-input bg-background px-3 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20" data-testid={testId} />
    </label>
  );
}