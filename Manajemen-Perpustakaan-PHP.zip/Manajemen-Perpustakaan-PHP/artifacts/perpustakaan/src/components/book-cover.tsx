import { BookOpen } from "lucide-react";

type CoverProps = {
  title: string;
  author?: string;
  cover?: string | null;
  size?: "small" | "medium" | "large";
  className?: string;
};

const colors = [
  "from-[#d6a35d] to-[#ad684c]",
  "from-[#96b4a4] to-[#496f6c]",
  "from-[#d4b1a1] to-[#9b5d59]",
  "from-[#c4a45f] to-[#7e6c45]",
  "from-[#91a8bb] to-[#4d6873]",
];

export function BookCover({ title, author = "", cover, size = "medium", className = "" }: CoverProps) {
  const initials = title.split(" ").filter(Boolean).slice(0, 2).map((word) => word[0]).join("").toUpperCase() || "PR";
  const color = colors[(title.length + author.length) % colors.length];
  const dimensions = size === "small" ? "h-[94px] w-[66px]" : size === "large" ? "h-[310px] w-[218px]" : "h-[190px] w-[133px]";

  if (cover) {
    return (
      <div className={`${dimensions} cover-sheen shrink-0 overflow-hidden rounded-[5px] bg-muted shadow-[5px_7px_0_hsl(185_30%_19%_/_0.08)] ${className}`}>
        <img src={cover} alt={`Cover of ${title}`} className="h-full w-full object-cover" data-testid={`img-cover-${title.replace(/\s+/g, "-").toLowerCase()}`} />
      </div>
    );
  }

  return (
    <div className={`${dimensions} cover-sheen relative shrink-0 overflow-hidden rounded-[5px] bg-gradient-to-br ${color} p-3 text-[#f8efdb] shadow-[5px_7px_0_hsl(185_30%_19%_/_0.08)] ${className}`} data-testid={`cover-fallback-${title.replace(/\s+/g, "-").toLowerCase()}`}>
      <div className="absolute inset-[7px] rounded-[2px] border border-[#f8efdb]/30" />
      <div className="relative flex h-full flex-col justify-between">
        <BookOpen size={size === "small" ? 12 : 16} strokeWidth={1.5} className="opacity-75" />
        <div>
          <div className={`font-display leading-[0.95] tracking-[-0.06em] ${size === "small" ? "text-[22px]" : size === "large" ? "text-[48px]" : "text-[32px]"}`}>{initials}</div>
          <div className="mt-2 line-clamp-2 text-[8px] font-semibold uppercase leading-[1.2] tracking-[0.12em] opacity-75">{title}</div>
        </div>
      </div>
    </div>
  );
}