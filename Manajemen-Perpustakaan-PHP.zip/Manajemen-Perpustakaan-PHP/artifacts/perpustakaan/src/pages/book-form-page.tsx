import { useEffect, useMemo } from "react";
import { ArrowLeft, BookOpen, LoaderCircle } from "lucide-react";
import { Link, useLocation, useRoute } from "wouter";
import {
  getGetBookQueryKey,
  getListCategoriesQueryKey,
  getGetCatalogSummaryQueryKey,
  useCreateBook,
  useGetBook,
  useGetCatalogSummary,
  useListCategories,
  useUpdateBook,
  type BookInput,
} from "@workspace/api-client-react";
import { AppShell } from "@/components/app-shell";
import { BookForm } from "@/components/book-form";

export default function BookFormPage() {
  const [, params] = useRoute("/books/:id/edit");
  const [, setLocation] = useLocation();
  const isEditing = Boolean(params?.id);
  const id = Number(params?.id ?? 0);
  const bookQuery = useGetBook(id, { query: { enabled: isEditing && Number.isFinite(id), queryKey: getGetBookQueryKey(id), retry: 1 } });
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey(), staleTime: 60_000 } });
  const summaryQuery = useGetCatalogSummary({ query: { queryKey: getGetCatalogSummaryQueryKey(), staleTime: 60_000 } });
  const createBook = useCreateBook();
  const updateBook = useUpdateBook();
  const categories = useMemo(() => categoriesQuery.data ?? summaryQuery.data?.categories?.map((item) => item.name) ?? [], [categoriesQuery.data, summaryQuery.data]);

  useEffect(() => {
    if (createBook.isSuccess && createBook.data) setLocation("/");
  }, [createBook.isSuccess, createBook.data, setLocation]);

  useEffect(() => {
    if (updateBook.isSuccess && updateBook.data) setLocation("/");
  }, [updateBook.isSuccess, updateBook.data, setLocation]);

  const submit = (values: BookInput) => {
    if (isEditing) {
      updateBook.mutate({ id, data: values }, {
        onSuccess: () => {
          void bookQuery.refetch();
        },
      });
    } else {
      createBook.mutate({ data: values });
    }
  };

  const isPending = createBook.isPending || updateBook.isPending;
  const mutationError = createBook.isError || updateBook.isError;

  return (
    <AppShell>
      <div className="mx-auto max-w-[1180px] px-5 py-8 md:px-10 md:py-10">
        <Link href="/" className="inline-flex items-center gap-2 text-[11px] font-bold text-muted-foreground transition hover:text-foreground" data-testid="link-back-catalog"><ArrowLeft size={15} /> Back to catalog</Link>
        <div className="mb-9 mt-8 flex items-end justify-between gap-5">
          <div>
            <div className="mb-3 flex items-center gap-2 font-mono-ui text-[9px] uppercase tracking-[0.21em] text-accent-foreground"><BookOpen size={13} /> Collection record</div>
            <h1 className="font-display text-[42px] leading-none tracking-[-0.06em] sm:text-[52px]">{isEditing ? "Refine a record." : "Add a new story."}</h1>
            <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground">{isEditing ? "Keep the details current so every volunteer can place this book with confidence." : "Give a good book a clear home in the reading room."}</p>
          </div>
          <span className="hidden font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground sm:block">{isEditing ? `Record ${id}` : "New record"}</span>
        </div>
        {isEditing && bookQuery.isLoading && <FormSkeleton />}
        {isEditing && bookQuery.isError && <div className="rounded-2xl border border-destructive/25 bg-destructive/6 p-8 text-center" role="alert" data-testid="status-book-load-error"><p className="font-display text-2xl">This record could not be found.</p><p className="mt-2 text-sm text-muted-foreground">Return to the catalog and choose another title.</p><Link href="/" className="mt-5 inline-flex h-10 items-center rounded-xl bg-primary px-4 text-xs font-bold text-primary-foreground" data-testid="link-error-back-catalog">Back to catalog</Link></div>}
        {(!isEditing || (!bookQuery.isLoading && !bookQuery.isError)) && <BookForm initialBook={bookQuery.data} categories={categories} onSubmit={submit} isPending={isPending} error={mutationError} />}
        {mutationError && <p className="mt-4 text-center text-xs text-destructive" data-testid="status-save-error">We couldn’t save this record. Check the details and try once more.</p>}
        <div className="mt-10 flex items-center justify-center gap-2 text-[10px] text-muted-foreground"><span className="h-1.5 w-1.5 rounded-full bg-[#6f977d]" /> Changes are saved directly to the Pustaka Raya catalog</div>
      </div>
    </AppShell>
  );
}

function FormSkeleton() {
  return <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_290px]" aria-label="Loading book record" data-testid="status-loading-book-form"><div className="h-[550px] animate-pulse rounded-2xl border border-border/70 bg-card p-7"><div className="h-7 w-64 rounded bg-muted" /><div className="mt-10 grid gap-5 sm:grid-cols-2">{[1, 2, 3, 4, 5, 6].map((item) => <div key={item} className="h-11 rounded-xl bg-muted" />)}</div></div><div className="h-[420px] animate-pulse rounded-2xl border border-border/70 bg-card" /></div>;
}