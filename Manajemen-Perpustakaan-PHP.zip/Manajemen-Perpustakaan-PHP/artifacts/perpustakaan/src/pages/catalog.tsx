import { useMemo, useState } from "react";
import { AlertCircle, ArrowUpRight, BookOpen, ChevronRight, CirclePlus, Filter, Pencil, RefreshCw, Search, Trash2, X } from "lucide-react";
import { Link } from "wouter";
import {
  getGetCatalogSummaryQueryKey,
  getListBooksQueryKey,
  getListCategoriesQueryKey,
  useDeleteBook,
  useGetCatalogSummary,
  useListBooks,
  useListCategories,
  type Book,
} from "@workspace/api-client-react";
import { AppShell } from "@/components/app-shell";
import { BookCover } from "@/components/book-cover";

export default function CatalogPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Book | null>(null);
  const params = useMemo(() => ({ ...(search.trim() ? { search: search.trim() } : {}), ...(category !== "all" ? { category } : {}) }), [search, category]);
  const booksQuery = useListBooks(params, { query: { queryKey: getListBooksQueryKey(params), staleTime: 20_000 } });
  const summaryQuery = useGetCatalogSummary({ query: { queryKey: getGetCatalogSummaryQueryKey(), staleTime: 30_000 } });
  const categoriesQuery = useListCategories({ query: { queryKey: getListCategoriesQueryKey(), staleTime: 60_000 } });
  const deleteBook = useDeleteBook();
  const books = booksQuery.data ?? [];
  const categories = categoriesQuery.data ?? summaryQuery.data?.categories?.map((item) => item.name) ?? [];
  const summary = summaryQuery.data;

  const confirmDelete = () => {
    if (!deleteTarget) return;
    deleteBook.mutate({ id: deleteTarget.id }, {
      onSuccess: () => {
        setDeleteTarget(null);
        setSelectedBook(null);
        void booksQuery.refetch();
        void summaryQuery.refetch();
        void categoriesQuery.refetch();
      },
    });
  };

  return (
    <AppShell>
      <div className="mx-auto max-w-[1480px] px-5 py-8 md:px-10 md:py-10">
        <section className="relative overflow-hidden rounded-[24px] border border-border/70 bg-[#e8d4a9] px-6 py-7 text-[#19383b] shadow-[0_10px_30px_hsl(185_30%_19%_/_0.05)] sm:px-9 sm:py-9 lg:px-12 lg:py-11">
          <div className="absolute -right-14 -top-24 h-72 w-72 rounded-full border-[32px] border-[#d6b76f]/50" />
          <div className="absolute -bottom-28 right-32 h-56 w-56 rounded-full border-[18px] border-[#d6b76f]/40" />
          <div className="relative max-w-2xl">
            <div className="mb-6 flex items-center gap-2 font-mono-ui text-[9px] uppercase tracking-[0.23em] text-[#19383b]/60"><span className="h-1.5 w-1.5 rounded-full bg-[#b76650]" /> The collection desk</div>
            <h1 className="max-w-[620px] font-display text-[43px] leading-[0.99] tracking-[-0.06em] sm:text-[57px]">A room for every story.</h1>
            <p className="mt-5 max-w-[465px] text-[14px] leading-relaxed text-[#19383b]/65">Keep the neighborhood’s shelves legible, inviting, and easy to return to. This is your living catalog.</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link href="/books/new" className="inline-flex h-11 items-center gap-2 rounded-xl bg-[#19383b] px-4 text-sm font-bold text-[#f8efdb] transition hover:-translate-y-0.5 hover:bg-[#254b4e]" data-testid="link-add-book-hero"><CirclePlus size={17} /> Add a book</Link>
              <span className="font-mono-ui text-[10px] uppercase tracking-[0.12em] text-[#19383b]/48">Last tidy-up · today</span>
            </div>
          </div>
          <div className="absolute bottom-7 right-9 hidden w-44 text-right lg:block">
            <p className="font-display text-[67px] leading-none tracking-[-0.08em]">{summary?.totalBooks ?? "—"}</p>
            <p className="mt-2 font-mono-ui text-[9px] uppercase tracking-[0.18em] text-[#19383b]/55">books on the shelves</p>
          </div>
        </section>

        <section className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-[1.05fr_1.05fr_1.5fr]">
          <MetricCard label="In the collection" value={summary?.totalBooks} detail="titles cataloged" icon={<BookOpen size={18} />} loading={summaryQuery.isLoading} />
          <MetricCard label="Distinct shelves" value={summary?.totalCategories} detail="ways to browse" icon={<Filter size={18} />} loading={summaryQuery.isLoading} accent />
          <div className="rounded-2xl border border-border/70 bg-card px-5 py-4">
            <div className="flex items-center justify-between">
              <span className="font-mono-ui text-[9px] uppercase tracking-[0.17em] text-muted-foreground">Recently added</span>
              <ArrowUpRight size={16} className="text-accent-foreground" />
            </div>
            {summaryQuery.isLoading ? <div className="mt-4 h-7 w-48 animate-pulse rounded bg-muted" /> : <p className="mt-3 truncate font-display text-[25px] tracking-[-0.04em]" data-testid="text-newest-book">{summary?.newestBook || "No books yet"}</p>}
            <p className="mt-1 text-[11px] text-muted-foreground">The latest title to find its place</p>
          </div>
        </section>

        <section className="mt-11">
          <div className="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="font-mono-ui text-[9px] uppercase tracking-[0.22em] text-muted-foreground">Browse the shelves</p>
              <h2 className="mt-2 font-display text-[32px] tracking-[-0.05em]">The catalog <span className="font-sans text-base font-normal tracking-normal text-muted-foreground">({booksQuery.isLoading ? "…" : books.length})</span></h2>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-muted-foreground"><span className="h-2 w-2 rounded-full bg-[#6f977d]" /> Search updates live</div>
          </div>

          <div className="mb-7 flex flex-col gap-3 rounded-2xl border border-border/70 bg-card p-3 sm:flex-row">
            <label className="relative flex min-h-11 flex-1 items-center">
              <Search size={17} className="absolute left-3.5 text-muted-foreground" />
              <input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by title, author, or publisher" className="h-11 w-full rounded-xl bg-background pl-10 pr-4 text-sm outline-none ring-1 ring-transparent transition placeholder:text-muted-foreground/70 focus:ring-accent/50" data-testid="input-search-books" />
            </label>
            <label className="relative sm:w-52">
              <span className="sr-only">Filter by category</span>
              <select value={category} onChange={(event) => setCategory(event.target.value)} className="h-11 w-full appearance-none rounded-xl border border-input bg-background px-3 pr-9 text-sm outline-none transition focus:border-accent" data-testid="select-category-filter">
                <option value="all">All categories</option>
                {categories.map((item) => <option value={item} key={item}>{item}</option>)}
              </select>
              <ChevronRight size={15} className="pointer-events-none absolute right-3 top-3.5 rotate-90 text-muted-foreground" />
            </label>
            {(search || category !== "all") && <button type="button" onClick={() => { setSearch(""); setCategory("all"); }} className="inline-flex h-11 items-center justify-center gap-2 rounded-xl px-3 text-xs font-bold text-muted-foreground transition hover:bg-muted hover:text-foreground" data-testid="button-clear-filters"><X size={14} /> Clear</button>}
          </div>

          {booksQuery.isLoading && <CatalogSkeleton />}
          {booksQuery.isError && <ErrorState onRetry={() => void booksQuery.refetch()} />}
          {!booksQuery.isLoading && !booksQuery.isError && books.length === 0 && <EmptyState search={search} onClear={() => { setSearch(""); setCategory("all"); }} />}
          {!booksQuery.isLoading && !booksQuery.isError && books.length > 0 && (
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {books.map((book, index) => <BookCard key={book.id} book={book} index={index} onOpen={() => setSelectedBook(book)} onDelete={() => setDeleteTarget(book)} />)}
            </div>
          )}
        </section>

        <footer className="mt-16 flex flex-col justify-between gap-2 border-t border-border/70 py-6 text-[10px] text-muted-foreground sm:flex-row">
          <span className="font-mono-ui uppercase tracking-[0.14em]">Pustaka Raya · Keep the shelves curious</span>
          <span>Built for small libraries, one record at a time.</span>
        </footer>
      </div>
      {selectedBook && <BookDetail book={selectedBook} onClose={() => setSelectedBook(null)} onDelete={() => setDeleteTarget(selectedBook)} />}
      {deleteTarget && <DeleteDialog book={deleteTarget} pending={deleteBook.isPending} onCancel={() => setDeleteTarget(null)} onConfirm={confirmDelete} />}
    </AppShell>
  );
}

function MetricCard({ label, value, detail, icon, loading, accent }: { label: string; value?: number; detail: string; icon: import("react").ReactNode; loading: boolean; accent?: boolean }) {
  return <div className={`rounded-2xl border border-border/70 px-5 py-4 ${accent ? "bg-[#d7e2d4]" : "bg-card"}`}><div className="flex items-center justify-between"><span className="font-mono-ui text-[9px] uppercase tracking-[0.17em] text-muted-foreground">{label}</span><span className="text-accent-foreground">{icon}</span></div>{loading ? <div className="mt-3 h-8 w-20 animate-pulse rounded bg-muted" /> : <p className="mt-2 font-display text-[31px] leading-none tracking-[-0.05em]" data-testid={`text-metric-${label.toLowerCase().replace(/\s+/g, "-")}`}>{value ?? 0}</p>}<p className="mt-2 text-[11px] text-muted-foreground">{detail}</p></div>;
}

function BookCard({ book, index, onOpen, onDelete }: { book: Book; index: number; onOpen: () => void; onDelete: () => void }) {
  return <article className={`book-card group relative flex min-h-[224px] cursor-pointer gap-4 rounded-2xl border border-border/70 bg-card p-4 opacity-0 [animation:page-enter_500ms_cubic-bezier(.22,1,.36,1)_forwards] ${index < 3 ? `stagger-${index + 1}` : ""}`} onClick={onOpen} data-testid={`card-book-${book.id}`}>
    <BookCover title={book.title} author={book.author} cover={book.cover} size="medium" />
    <div className="flex min-w-0 flex-1 flex-col">
      <div className="flex items-start justify-between gap-2">
        <span className="font-mono-ui text-[9px] uppercase tracking-[0.12em] text-muted-foreground">{book.category}</span>
        <div className="flex gap-0.5 opacity-0 transition-opacity group-hover:opacity-100">
          <Link href={`/books/${book.id}/edit`} onClick={(event) => event.stopPropagation()} className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground" aria-label={`Edit ${book.title}`} data-testid={`link-edit-book-${book.id}`}><Pencil size={14} /></Link>
          <button type="button" onClick={(event) => { event.stopPropagation(); onDelete(); }} className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive" aria-label={`Delete ${book.title}`} data-testid={`button-delete-book-${book.id}`}><Trash2 size={14} /></button>
        </div>
      </div>
      <h3 className="mt-3 line-clamp-3 font-display text-[23px] leading-[1.02] tracking-[-0.04em]">{book.title}</h3>
      <p className="mt-2 truncate text-xs font-semibold text-foreground/70">{book.author}</p>
      <div className="mt-auto flex items-end justify-between gap-2 pt-4">
        <span className="font-mono-ui text-[10px] text-muted-foreground">{book.publicationYear} · {book.publisher}</span>
        <span className="grid h-7 w-7 place-items-center rounded-full bg-secondary text-secondary-foreground transition group-hover:bg-accent"><ChevronRight size={14} /></span>
      </div>
    </div>
  </article>;
}

function BookDetail({ book, onClose, onDelete }: { book: Book; onClose: () => void; onDelete: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#19383b]/45 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" data-testid="dialog-book-detail">
    <div className="relative max-h-[90vh] w-full max-w-2xl overflow-auto rounded-3xl border border-border bg-card p-6 shadow-2xl sm:p-8">
      <button type="button" onClick={onClose} className="absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-full bg-muted text-muted-foreground hover:text-foreground" aria-label="Close book details" data-testid="button-close-book-detail"><X size={17} /></button>
      <div className="flex flex-col gap-6 sm:flex-row">
        <BookCover title={book.title} author={book.author} cover={book.cover} size="large" className="mx-auto sm:mx-0" />
        <div className="min-w-0 pt-1">
          <span className="font-mono-ui text-[9px] uppercase tracking-[0.2em] text-accent-foreground">{book.category}</span>
          <h2 className="mt-3 font-display text-[34px] leading-[0.98] tracking-[-0.05em]" data-testid={`text-detail-title-${book.id}`}>{book.title}</h2>
          <p className="mt-3 text-sm font-semibold text-foreground/70">{book.author}</p>
          <p className="mt-1 font-mono-ui text-[10px] text-muted-foreground">{book.publisher} · {book.publicationYear}</p>
          <p className="mt-7 text-sm leading-relaxed text-foreground/70">{book.description || "No description has been added yet. A little context here can help this title find its next reader."}</p>
        </div>
      </div>
      <div className="mt-8 flex flex-wrap justify-end gap-2 border-t border-border/70 pt-5">
        <button type="button" onClick={onDelete} className="mr-auto inline-flex h-10 items-center gap-2 rounded-xl px-3 text-xs font-bold text-destructive hover:bg-destructive/10" data-testid={`button-detail-delete-${book.id}`}><Trash2 size={14} /> Delete</button>
        <button type="button" onClick={onClose} className="h-10 rounded-xl px-4 text-xs font-bold text-muted-foreground hover:bg-muted" data-testid="button-dismiss-detail">Close</button>
        <Link href={`/books/${book.id}/edit`} className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-xs font-bold text-primary-foreground" data-testid={`link-detail-edit-${book.id}`}><Pencil size={14} /> Edit record</Link>
      </div>
    </div>
  </div>;
}

function DeleteDialog({ book, pending, onCancel, onConfirm }: { book: Book; pending: boolean; onCancel: () => void; onConfirm: () => void }) {
  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-[#19383b]/50 p-4 backdrop-blur-sm" role="alertdialog" aria-modal="true" data-testid="dialog-delete-book">
    <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl">
      <div className="mb-5 grid h-11 w-11 place-items-center rounded-xl bg-destructive/10 text-destructive"><Trash2 size={19} /></div>
      <h2 className="font-display text-[26px] tracking-[-0.04em]">Remove this record?</h2>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">“{book.title}” will be removed from the collection. This can’t be undone.</p>
      <div className="mt-7 flex justify-end gap-2">
        <button type="button" onClick={onCancel} className="h-10 rounded-xl px-4 text-xs font-bold text-muted-foreground hover:bg-muted" data-testid="button-cancel-delete">Keep record</button>
        <button type="button" onClick={onConfirm} disabled={pending} className="inline-flex h-10 items-center gap-2 rounded-xl bg-destructive px-4 text-xs font-bold text-destructive-foreground disabled:opacity-60" data-testid="button-confirm-delete"><Trash2 size={14} /> {pending ? "Removing…" : "Remove record"}</button>
      </div>
    </div>
  </div>;
}

function CatalogSkeleton() {
  return <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" aria-label="Loading catalog" data-testid="status-loading-catalog">{[1, 2, 3, 4, 5, 6].map((item) => <div key={item} className="flex min-h-[224px] gap-4 rounded-2xl border border-border/70 bg-card p-4"><div className="h-[190px] w-[133px] animate-pulse rounded-[5px] bg-muted" /><div className="flex-1 space-y-3 pt-1"><div className="h-3 w-16 animate-pulse rounded bg-muted" /><div className="h-16 w-full animate-pulse rounded bg-muted" /><div className="mt-8 h-3 w-24 animate-pulse rounded bg-muted" /></div></div>)}</div>;
}

function ErrorState({ onRetry }: { onRetry: () => void }) {
  return <div className="rounded-2xl border border-destructive/25 bg-destructive/6 px-6 py-12 text-center" role="alert" data-testid="status-catalog-error"><AlertCircle className="mx-auto text-destructive" size={26} /><h3 className="mt-4 font-display text-2xl">The shelves are taking a moment.</h3><p className="mt-2 text-sm text-muted-foreground">We couldn’t load the catalog just now.</p><button type="button" onClick={onRetry} className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl border border-border bg-card px-4 text-xs font-bold hover:bg-muted" data-testid="button-retry-catalog"><RefreshCw size={14} /> Try again</button></div>;
}

function EmptyState({ search, onClear }: { search: string; onClear: () => void }) {
  return <div className="rounded-2xl border border-dashed border-border bg-card/45 px-6 py-16 text-center" data-testid="status-empty-catalog"><div className="mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground"><BookOpen size={21} /></div><h3 className="mt-5 font-display text-2xl">{search ? "No matching titles." : "The first shelf is still waiting."}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground">{search ? "Try a different phrase or clear the search to see every record." : "Start the collection with a book that deserves a place here."}</p>{search ? <button type="button" onClick={onClear} className="mt-5 h-10 rounded-xl bg-primary px-4 text-xs font-bold text-primary-foreground" data-testid="button-empty-clear-search">Clear search</button> : <Link href="/books/new" className="mt-5 inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-xs font-bold text-primary-foreground" data-testid="link-empty-add-book"><CirclePlus size={14} /> Add first book</Link>}</div>;
}