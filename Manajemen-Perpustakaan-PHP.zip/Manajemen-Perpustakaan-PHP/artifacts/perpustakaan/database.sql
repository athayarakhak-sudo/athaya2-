-- Skema MariaDB referensi untuk instalasi PHP Native.
-- Versi aplikasi Replit menggunakan PostgreSQL terkelola dengan struktur kolom yang sama.

CREATE DATABASE IF NOT EXISTS db_perpustakaan
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE db_perpustakaan;

CREATE TABLE IF NOT EXISTS buku (
  id INT PRIMARY KEY AUTO_INCREMENT,
  judul VARCHAR(255) NOT NULL,
  pengarang VARCHAR(150) NOT NULL,
  penerbit VARCHAR(150) NOT NULL,
  tahun_terbit INT NOT NULL,
  kategori VARCHAR(100) NOT NULL,
  deskripsi TEXT NULL,
  foto VARCHAR(255) NOT NULL DEFAULT 'default.jpg',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, kategori, deskripsi, foto)
SELECT 'Laut Bercerita', 'Leila S. Chudori', 'Kepustakaan Populer Gramedia', 2017,
       'Fiksi', 'Novel tentang persahabatan, kehilangan, dan keberanian untuk mengingat.', 'default.jpg'
WHERE NOT EXISTS (SELECT 1 FROM buku);

INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, kategori, deskripsi, foto)
SELECT 'Filosofi Teras', 'Henry Manampiring', 'Penerbit Buku Kompas', 2018,
       'Pengembangan Diri', 'Pengantar filsafat Stoa yang praktis untuk kehidupan modern.', 'default.jpg'
WHERE NOT EXISTS (SELECT 1 FROM buku WHERE judul = 'Filosofi Teras');

INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, kategori, deskripsi, foto)
SELECT 'Bumi Manusia', 'Pramoedya Ananta Toer', 'Lentera Dipantara', 1980,
       'Sastra', 'Kisah Minke dan pergulatan manusia di tengah perubahan zaman.', 'default.jpg'
WHERE NOT EXISTS (SELECT 1 FROM buku WHERE judul = 'Bumi Manusia');

INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, kategori, deskripsi, foto)
SELECT 'Atomic Habits', 'James Clear', 'Avery', 2018,
       'Produktivitas', 'Cara membangun kebiasaan baik melalui perubahan kecil yang konsisten.', 'default.jpg'
WHERE NOT EXISTS (SELECT 1 FROM buku WHERE judul = 'Atomic Habits');

INSERT INTO buku (judul, pengarang, penerbit, tahun_terbit, kategori, deskripsi, foto)
SELECT 'Sapiens', 'Yuval Noah Harari', 'Harper', 2015,
       'Sejarah', 'Sejarah singkat umat manusia dari zaman pemburu hingga era modern.', 'default.jpg'
WHERE NOT EXISTS (SELECT 1 FROM buku WHERE judul = 'Sapiens');